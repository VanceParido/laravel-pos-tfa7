

<?php $__env->startSection('content'); ?>
    <h1>Edit User</h1>

    <form
        action="<?php echo e(route('users.update', $user)); ?>"
        method="POST"
        enctype="multipart/form-data"
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label for="username">Username</label><br>
            <input
                type="text"
                id="username"
                name="username"
                value="<?php echo e(old('username', $user->username)); ?>"
                maxlength="255"
                required
            >

            <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #b91c1c;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <br>

        <div>
            <label for="full_name">Full Name</label><br>
            <input
                type="text"
                id="full_name"
                name="full_name"
                value="<?php echo e(old('full_name', $user->full_name)); ?>"
                maxlength="255"
                required
            >

            <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #b91c1c;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <br>

        <?php if($user->avatar): ?>
            <div>
                <p>Current Profile Picture</p>
                <img
                    src="<?php echo e(asset('storage/' . $user->avatar)); ?>"
                    alt="Profile picture of <?php echo e($user->full_name); ?>"
                    width="100"
                    height="100"
                    style="object-fit: cover; border-radius: 8px;"
                >
            </div>

            <br>
        <?php endif; ?>

        <div>
            <label for="avatar">Profile Picture</label><br>
            <input
                type="file"
                id="avatar"
                name="avatar"
                accept="image/jpeg,image/png,image/webp"
                aria-describedby="avatar-help"
            >

            <p id="avatar-help">
                JPG, PNG, or WebP. Maximum 2 MB and 4096 × 4096 pixels.
                Leave empty to keep your current picture.
            </p>

            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color: #b91c1c;"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <br>

        <button type="submit">Update User</button>
        <a href="<?php echo e(route('users.index')); ?>">Cancel</a>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vance\Downloads\myproj\resources\views/users/edit.blade.php ENDPATH**/ ?>