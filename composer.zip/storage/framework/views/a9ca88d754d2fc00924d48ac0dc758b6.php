

<?php $__env->startSection('content'); ?>
    <h1>User Accounts</h1>

    <?php if(session('success')): ?>
        <p style="color: #166534;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <p>
        <a href="<?php echo e(route('users.create')); ?>">Create User</a>
    </p>

    <table>
        <thead>
            <tr>
                <th>User ID</th>
                <th>Avatar</th>
                <th>Username</th>
                <th>Full Name</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>

                    <td>
                        <img
                            src="<?php echo e($user->avatar
                                ? asset('storage/' . $user->avatar)
                                : asset('images/avatar-placeholder.svg')); ?>"
                            alt="Avatar for <?php echo e($user->full_name); ?>"
                            width="80"
                            height="80"
                            style="object-fit: cover; border-radius: 8px;"
                        >
                    </td>

                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->full_name); ?></td>

                    <td>
                        <a href="<?php echo e(route('users.edit', $user)); ?>">
                            Edit
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No users found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\vance\Downloads\myproj\resources\views/users/index.blade.php ENDPATH**/ ?>