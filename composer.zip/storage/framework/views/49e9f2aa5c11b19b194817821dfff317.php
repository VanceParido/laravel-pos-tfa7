

<?php $__env->startSection('content'); ?>
    <h1>Laravel POS System</h1>

    <p>Welcome to the Laravel Point of Sale System.</p>

    <p>
        This application demonstrates Laravel routes, controllers,
        Blade templates, navigation links, and static PHP array data.
    </p>

    <h2>Available Pages</h2>

    <ul>
        <li>Home Page</li>
        <li>About Page</li>
        <li>Customer Accounts</li>
        <li>User Accounts</li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myproj\resources\views/home.blade.php ENDPATH**/ ?>