

<?php $__env->startSection('content'); ?>
    <h1>About Laravel POS</h1>

    <p>
        Laravel POS is a simple Point of Sale foundation project
        created for Technical Formative Assessment 5.
    </p>

    <p>
        It uses Laravel MVC architecture. Routes direct requests to
        controllers, controllers process data, and Blade views display
        the output in the browser.
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\myproj\myproj\resources\views/about.blade.php ENDPATH**/ ?>